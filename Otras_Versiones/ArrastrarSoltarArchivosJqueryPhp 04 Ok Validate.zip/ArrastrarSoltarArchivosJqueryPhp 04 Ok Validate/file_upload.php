<?php 
//include_once("db_connect.php");
if(!empty($_FILES)){  

    // PARAMETROS INICIALES VALIDACION

      global $extension;
      $extension = substr($_FILES["file"]["name"],-4);
      $extension = strtolower($extension);

      // EL ARRAY DE VALIDACION HA DE CONICIDIR CON acceptedFiles: EN DROPZONE.JS
      // PUEDO LIMITAR LA VALIDACION EN LOS DOS ARCHIVOS PERO DROPZONE NO PASARÁ ERROR
      $ext_file = array('.jpg','.png','jpeg','.avi','.mkv','.mp4','.pdf');
      $ext_file = in_array($extension, $ext_file);

if ($ext_file) {

        global $upload_dir;
        $upload_dir = "uploads/";
        global $fileName;
        $fileName = $_FILES['file']['name'];
        global $uploaded_file;
        $uploaded_file = $upload_dir.$fileName;   

    if(move_uploaded_file($_FILES['file']['tmp_name'],$uploaded_file)){

        //insert file information into db table
        /*
		$mysql_insert = "INSERT INTO uploads (file_name, upload_time)VALUES('".$fileName."','".date("Y-m-d H:i:s")."')";
        mysqli_query($conn, $mysql_insert) or die("database error:". mysqli_error($conn));
        */

    }else{ }

  } // FIN $_FILES TYPE

} // FIN EMPTY $_FILES
